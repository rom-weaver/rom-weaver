Synthetic documentation only.
